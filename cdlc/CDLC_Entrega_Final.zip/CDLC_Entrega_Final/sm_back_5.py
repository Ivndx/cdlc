#!/usr/bin/env python3

import rclpy
import math
import numpy as np
from rclpy.node import Node
from turtlesim.msg import Pose
from std_msgs.msg import Bool
from std_msgs.msg import Float32
from geometry_msgs.msg import Twist
from aruco_opencv_msgs.msg import ArucoDetection
from rclpy.qos import QoSProfile, ReliabilityPolicy, DurabilityPolicy


#Maquina de estados para el control del sistema. 
class MainCoordinator(Node):
    def __init__(self):
        super().__init__('main_coordinator')
        self.get_logger().info("SM GOOOOOO ")

        qos_profile = QoSProfile(reliability=ReliabilityPolicy.BEST_EFFORT, durability=DurabilityPolicy.VOLATILE, depth=1)

        # Publicadores para el control del algoritmo de navegación 
        self.target_pub = self.create_publisher(Pose, 'target', 10)
        self.servo_pub = self.create_publisher(Float32, 'ServoAngle', 10)
        self.pub = self.create_publisher(Twist, 'cmd_vel', 1)

        # Subscriptores para las banderas de posición para rutinas de alineación y cambios de estado (liberadas por Bug0). 
        self.create_subscription(Bool, 'close_enough', self.close_enough_callback, 10)
        self.create_subscription(Bool, 'goal_reached', self.goal_reached_callback, 10)
        self.create_subscription(Pose, 'PosicionBot', self.robot_pose_callback, 10)
        
        # Suscriptor para la lectura del aruco ubicado en la carga. 
        self.aruco_sub = self.create_subscription(ArucoDetection, "aruco_detections", self.aruco_callback, qos_profile)
        
        #Estado incial de la maquina de estados. 
        self.state = "start"
        self.timer = self.create_timer(0.1, self.state_machine) 

        # Variables de transición entre estados.
        self.close_enough = False
        self.goal_reached = False
        self.dropoff_sent = False
        self.returned_home = False
        self.orientation_started = False
        self.routine_index = 0
        self.servo_counter = 0

        # Variables para el aruco ubicado en la carga. 
        self.aruco_0_detected = False
        self.aruco_0_position = None  # Posición en coordenadas del mundo
        self.aruco_0_distance = None
        self.last_aruco_position = None  # Para mantener última posición conocida
        self.robot_position = Pose()  # Posición actual del robot
        
        # Variables para control de pérdida de ArUco
        self.aruco_lost_count = 0
        self.max_aruco_lost_count = 30  # ~3 segundos con timer de 0.1s
        
        # Parámetros de configuración
        self.aruco_detection_threshold = 0.7  # 70cm para detectar ArUco 0 (más lejos)
        self.pickup_final_distance = 0.2     # 20cm distancia final para pick-up
        
        # Matriz de transformación cámara-robot (misma que en odometría)
        self.offset_x = 0.075
        self.offset_z = 0.065
        self.T_cam_robot = np.array([
            [0.0, 0.0, 1.0, self.offset_x],
            [-1.0, 0.0, 0.0, 0.0],
            [0.0, -1.0, 0.0, self.offset_z],
            [0.0, 0.0, 0.0, 1.0]
        ])
        
        # Mensaje de Twist para el movimiento hacia atrás
        self.msg = Twist()

    #Método de procesamiento del posición del Aruco 0.
    def aruco_callback(self, msg):
        aruco_found = False
        
        for aruco in msg.markers:
            if aruco.marker_id == 0:  # Solo nos interesa el ArUco 0
                aruco_found = True
                
                # Transformar posición de cámara a robot
                pos_cam = np.array([
                    [aruco.pose.position.x],
                    [aruco.pose.position.y],
                    [aruco.pose.position.z],
                    [1.0]
                ])
                pos_robot_frame = self.T_cam_robot @ pos_cam
                
                # Calcular posición en coordenadas del mundo
                robot_x = self.robot_position.x
                robot_y = self.robot_position.y
                robot_theta = self.robot_position.theta
                
                # Rotar del frame del robot al frame del mundo
                cos_theta = math.cos(robot_theta)
                sin_theta = math.sin(robot_theta)
                
                aruco_world_x = robot_x + pos_robot_frame[0, 0] * cos_theta - pos_robot_frame[1, 0] * sin_theta
                aruco_world_y = robot_y + pos_robot_frame[0, 0] * sin_theta + pos_robot_frame[1, 0] * cos_theta
                
                self.aruco_0_position = (aruco_world_x, aruco_world_y)
                
                # Calcular distancia al ArUco
                dx = aruco_world_x - robot_x
                dy = aruco_world_y - robot_y
                self.aruco_0_distance = math.sqrt(dx*dx + dy*dy)
                
                # Reset contador de pérdida
                self.aruco_lost_count = 0
                self.get_logger().info(f"ArUco 0 detectado en mundo: ({aruco_world_x:.3f}, {aruco_world_y:.3f}), "
                                     f"distancia: {self.aruco_0_distance:.3f}m")
                break
        
        # Actualizar estado de detección del aruco de la carga. 
        if aruco_found:
            self.aruco_0_detected = True
        else:
            # Incrementar contador de pérdida solo si estaba detectado antes
            if self.aruco_0_detected:
                self.aruco_lost_count += 1
                if self.aruco_lost_count >= self.max_aruco_lost_count:
                    self.aruco_0_detected = False
                    self.get_logger().warn("ArUco 0 perdido por mucho tiempo")

    
    #Callback de la pose actual del Robot. 
    def robot_pose_callback(self, msg):
        self.robot_position = msg

    #Callbacks de las banderas liberadas por el Bug0. 
    def close_enough_callback(self, msg):
        self.close_enough = msg.data
    def goal_reached_callback(self, msg):
        self.goal_reached = msg.data

    #Publicador de poses objetivo para el algoritmo de navegación autonoma. 
    def publish_target(self, x, y):
        pose = Pose()
        pose.x = x
        pose.y = y
        pose.theta = 0.0
        self.target_pub.publish(pose)
        self.get_logger().info(f"Sent target: ({x:.2f}, {y:.2f})")

    
    #Método que que genera los puntos intermedios entre la distancia determinada para el inicio del rango acercamiento a la carga
    # hasta alinearse con la cámara. 
    def generate_straight_approach_points(self, aruco_x, aruco_y):
        # Distancias de aproximación desde el ArUco (en X)
        x_offsets = [0.5, 0.25, 0.10]  #
        
        approach_points = []
    
        # Determinar la dirección de aproximación basada en la posición del robot
        robot_x = self.robot_position.x
    
        # Si el robot está a la izquierda del ArUco, aproximarse desde la izquierda
        # Si está a la derecha, aproximarse desde la derecha
        if robot_x < aruco_x:
            # Aproximarse desde la izquierda (robot va hacia la derecha)
            for offset in x_offsets:
                point_x = aruco_x - offset  # Puntos antes del ArUco en X
                point_y = aruco_y  # Y constante
                approach_points.append((point_x, point_y))
        else:
            # Aproximarse desde la derecha (robot va hacia la izquierda)
            for offset in x_offsets:
                point_x = aruco_x + offset  # Puntos después del ArUco en X
                point_y = aruco_y  # Y constante
                approach_points.append((point_x, point_y))
        
        self.get_logger().info(f"Generados {len(approach_points)} puntos de aproximación recta")
        for i, (px, py) in enumerate(approach_points):
            self.get_logger().info(f"Punto {i+1}: ({px:.3f}, {py:.3f})")
        
        return approach_points

    def state_machine(self):
        if self.state == "start":
            self.get_logger().info("State: GO_TO_PICK_UP")
            angle = 260.0
            self.servo_pub.publish(Float32(data=angle))
            self.state = "go_to_pick_up"
            # Inicialmente ir hacia la posición "aproximada" de la zona de carga. 
            self.publish_target(1.15, 0.0)
            
        elif self.state == "go_to_pick_up":
            # Publicar el target continuamente para asegurar que el robot se dirija al área de descarga.
            if not self.aruco_0_detected:
                self.publish_target(1.15, 0.0)
            
            # Verificar si detectamos ArUco 0 y estamos suficientemente cerca
            if self.aruco_0_detected and self.aruco_0_distance is not None:
                self.get_logger().info(f"ArUco detectado a distancia: {self.aruco_0_distance:.3f}m, threshold: {self.aruco_detection_threshold:.3f}m")
                
                #Si se encuentra dentro del rango de distancia de acercamiento, entra en rutina de alineación con el objetivo. 
                if self.aruco_0_distance <= self.aruco_detection_threshold:
                    self.get_logger().info(f"ArUco 0 detectado a {self.aruco_0_distance:.2f}m. Switching to PICK_UP_ORIENTATION")
                    self.state = "pick_up_orientation"
                    self.routine_index = 0
                    self.goal_reached = False
                    self.orientation_started = False
                    # Limpiar variables de aproximación
                    if hasattr(self, 'approach_points'):
                        delattr(self, 'approach_points')

        elif self.state == "pick_up_orientation":
            #Publicación para bajar el servomotor. 
            angle = 260.0
            self.servo_pub.publish(Float32(data=angle))

            # Siempre verificar si tenemos ArUco detectado
            if self.aruco_0_detected and self.aruco_0_position:
                aruco_x, aruco_y = self.aruco_0_position
                self.last_aruco_position = (aruco_x, aruco_y)
                
                # Generar puntos de aproximación 
                if not hasattr(self, 'approach_points') or not self.approach_points:
                    self.approach_points = self.generate_straight_approach_points(aruco_x, aruco_y)
                    self.current_approach_index = 0
                    self.get_logger().info("Puntos de aproximación generados")
            
            # Usar la última posición conocida 
            elif self.last_aruco_position and not hasattr(self, 'approach_points'):
                aruco_x, aruco_y = self.last_aruco_position
                self.approach_points = self.generate_straight_approach_points(aruco_x, aruco_y)
                self.current_approach_index = 0
                self.get_logger().info("Usando última posición conocida del ArUco")
            
            # Ejecutar aproximación 
            if hasattr(self, 'approach_points') and self.approach_points:
                # Ejecutar los puntos de aproximación uno por uno
                if self.current_approach_index < len(self.approach_points):
                    target_x, target_y = self.approach_points[self.current_approach_index]
                    self.publish_target(target_x, target_y)
                    
                    dx = target_x - self.robot_position.x
                    dy = target_y - self.robot_position.y
                    distance = math.hypot(dx, dy)
                    
                    self.get_logger().info(f"Aproximándose al punto {self.current_approach_index + 1}/{len(self.approach_points)}, "
                                         f"distancia restante: {distance:.3f}m")
                    
                    if distance < 0.10:  # Tolerancia 
                        self.current_approach_index += 1
                        self.get_logger().info(f"Punto {self.current_approach_index} alcanzado")
                else:
                    # Último paso: ir al punto final del ArUco
                    if self.last_aruco_position:
                        aruco_x, aruco_y = self.last_aruco_position
                        self.publish_target(aruco_x, aruco_y)
                        
                        dx = aruco_x - self.robot_position.x
                        dy = aruco_y - self.robot_position.y
                        distance_to_aruco = math.hypot(dx, dy)
                        
                        self.get_logger().info(f"Aproximación final al ArUco, distancia: {distance_to_aruco:.3f}m")
                        
                        if distance_to_aruco <= self.pickup_final_distance:
                            self.get_logger().info("Aproximación final completada. Switching to START_SERVO.")
                            self.previous_state = "pick_up_orientation"
                            # Limpiar variables
                            if hasattr(self, 'approach_points'):
                                delattr(self, 'approach_points')
                            self.state = "start_servo"
            else:
                self.get_logger().warn("No ArUco position known yet. Esperando detección...")
                
                # Si llevamos mucho tiempo sin detección, volver al estado anterior
                if not hasattr(self, 'no_aruco_count'):
                    self.no_aruco_count = 0
                else:
                    self.no_aruco_count += 1
                    if self.no_aruco_count > 50:  # ~5 segundos
                        self.get_logger().warn("Sin detección de ArUco por mucho tiempo. Volviendo a GO_TO_PICK_UP")
                        self.state = "go_to_pick_up"
                        if hasattr(self, 'no_aruco_count'):
                            delattr(self, 'no_aruco_count')

        elif self.state == "start_servo":
            if not hasattr(self, 'servo_start_time'):
                # Publicar solo una vez el ángulo correspondiente
                #Primera vez, se sube el servo para recolección y el segundo lo baja para el drop-off. 
                if self.servo_counter == 0:
                    angle = -300.0
                    self.get_logger().info("Publishing servo angle for pick-up (-300.0)")
                else:
                    angle = 260.0
                    self.get_logger().info("Publishing servo angle for drop-off (260.0)")

                self.servo_pub.publish(Float32(data=angle))
                self.servo_counter = 1 - self.servo_counter

                self.servo_start_time = self.get_clock().now()
            else:
                elapsed_time = (self.get_clock().now() - self.servo_start_time).nanoseconds / 1e9
                if elapsed_time > 3.0:
                    del self.servo_start_time
                    if self.previous_state == "pick_up_orientation":
                        self.dropoff_sent = False
                        self.goal_reached = False
                        self.state = "go_to_drop_off"
                    else:
                        self.state = "go_backwards"

        #Estado que se dirige al area de descarga. 
        elif self.state == "go_to_drop_off":
            if not self.dropoff_sent:
                self.publish_target(-1.05, 0.0)
                self.dropoff_sent = True
                self.get_logger().info("Sent drop-off target: (-1.05, 0.0)")
            elif self.goal_reached:
                self.get_logger().info("Reached drop-off target. Switching to START_SERVO.")
                self.previous_state = "go_to_drop_off"
                self.goal_reached = False
                self.dropoff_sent = False
                self.state = "start_servo"

        #Estado después de dejar la carga, para distanciarse de ella y garantizar que no se mueva por 3.5 segundos. 
        elif self.state == "go_backwards":
            if not hasattr(self, 'backwards_start_time'):
                self.get_logger().info("State: GO_BACKWARDS - Moving backwards for 3.5 seconds")
                self.backwards_start_time = self.get_clock().now()
                
                self.msg.linear.x = -0.15
                self.msg.angular.z = 0.0
                self.pub.publish(self.msg)
            else:
                self.msg.linear.x = -0.15
                self.msg.angular.z = 0.0
                self.pub.publish(self.msg)
                
                elapsed_time = (self.get_clock().now() - self.backwards_start_time).nanoseconds / 1e9
                if elapsed_time > 3.5:
                    self.msg.linear.x = 0.0
                    self.msg.angular.z = 0.0
                    self.pub.publish(self.msg)
                    
                    del self.backwards_start_time
                    self.get_logger().info("Finished going backwards. Transitioning to DONE state.")
                    self.state = "done"

        #Al terminar la descarga y alejarse de ella, el robot regresa al origen. 
        elif self.state == "done":
            if not self.returned_home:
                self.get_logger().info("Returning to origin (0.0, 0.0)")
                self.publish_target(0.0, 0.0)
                self.returned_home = True
            elif self.goal_reached:
                self.get_logger().info("Robot arrived at origin. State machine complete.")
                self.state = "idle"

        elif self.state == "idle":
            pass


def main(args=None):

    rclpy.init(args=None)
    node = MainCoordinator()
    try:rclpy.spin(node)
    except KeyboardInterrupt: print("SM Killed NOOOOOOOOOOOOOOOo ")
    except Exception as e: print(f"Error en el nodo: {e}")


if __name__ == "__main__":
    main()